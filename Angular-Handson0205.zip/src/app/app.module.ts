import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { EmployeeComponentComponent } from './employee-component/employee-component.component';
import { EmployeeComponent } from './employee/employee.component';
// import { EditEmpReactiveComponent } from './edit-emp-reactive/edit-emp-reactive.component';
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import { ViewEmployeeComponent } from './view-employee/view-employee.component';
import { EditEmployeeComponent } from './edit-employee/edit-employee.component';
import { MenuComponent } from './menu/menu.component';
import {AppRoutingModule} from "./app-routing.module";
import { QuantityIncreamentComponent } from './quantity-increament/quantity-increament.component';
import { EditEmployeeTemplateComponent } from './edit-employee-template/edit-employee-template.component';

@NgModule({
  declarations: [
    AppComponent,
    EmployeeComponentComponent,
    EmployeeComponent,
    ViewEmployeeComponent,
    EditEmployeeComponent,
    MenuComponent,
    QuantityIncreamentComponent,
    EditEmployeeTemplateComponent
  ],
    imports: [
        BrowserModule,
        ReactiveFormsModule,
        AppRoutingModule,
        FormsModule
    ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
